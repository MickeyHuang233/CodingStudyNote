package com.mickey.study;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class T13_DiamondOperator {
    @Test
    @DisplayName("鑽石操作符(Diamond Operator)使用改進")
    public void testcase01() {
        // JDK7，<>中必須填寫類型
        final Set<String> set1 = new HashSet<String>();

        // JDK8，<>中可空白，類型推斷
        final Set<String> set2 = new HashSet<>();

        // JDK9，<>可以與匿名實現類同時使用
        final Set<String> set3 = new HashSet<>();
        set3.add("Mikcey");
        set3.add("Tai");
        set3.add("Molly");
        final List<String> list3 = new ArrayList<>(set3);
        for (final String str : list3) {
            System.out.println(str);
        }
    }
}
