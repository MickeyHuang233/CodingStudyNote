package com.mickey.study;

/**
 * 接口定義私有方法
 *
 * @author a0909
 *
 */
public interface T12_InterfacePrivateMethod {
    // JDK7，只能聲明全局常量(public static final)和抽象方法(public abstract)
    public void method1();

    // JDK8，聲明靜態方法 和 默認方法
    public static void method2() {
        System.out.println("do something in method2.");
    }

    public default void method3() {
        System.out.println("do something in method3.");
        this.method4();
    }

    // JDK9，聲明私有方法
    private void method4() {
        System.out.println("do something in method4.");
    }
}
