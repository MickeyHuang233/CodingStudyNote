package com.mickey.study;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class T21_HttpClient {
    @Test
    @DisplayName("新Http客戶端API")
    public void testcase01() {
        try {
            final HttpClient client = HttpClient.newHttpClient();
            final HttpRequest request = HttpRequest.newBuilder(URI.create("https://www.google.com.tw/"))//
                    .GET().build();
            HttpResponse<String> response = null;
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println(response.statusCode());// 響應碼
            System.out.println(response.version().name());// 協議版本
            System.out.println(response.body());// 響應體
        } catch (final IOException e) {
            e.printStackTrace();
        } catch (final InterruptedException e) {
            e.printStackTrace();
        }
    }
}
