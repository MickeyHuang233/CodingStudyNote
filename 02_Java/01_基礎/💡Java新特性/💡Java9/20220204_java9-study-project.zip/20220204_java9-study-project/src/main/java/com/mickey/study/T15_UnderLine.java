package com.mickey.study;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class T15_UnderLine {
    @Test
    @DisplayName("JDK9之前，變量名可以為_")
    public void testcase01() {
        //        final String _ = "under line";
        //        System.out.println(_);
    }
}