package com.mickey.study;

import java.util.logging.Logger;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.mickey.importtest.T08_User1;

public class T08_JigsawTest {
    private Logger logger = Logger.getLogger(this.getClass().getName());

    @Test
    @DisplayName("測試java9新特性，Jigsaw")
    public void testcase01() {
        final T08_User1 user1 = new T08_User1("Mikcey", 233);
        this.logger.info(user1.toString());
        // 因為T08_User2所在的包沒在module-info.java設置暴露，所以會報錯
        //        final T08_User2 user2 = new T08_User2("Mikcey", 233);
    }
}
