package com.mickey.study;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class T18_StreamAPI {
    @Test
    @DisplayName("Stream API新增方法")
    public void testcase01() {
        final List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
        System.out.println("takeWhile()");
        list.stream().takeWhile(x -> x < 3 || x > 10).forEach(System.out::println);

        System.out.println("dropWhile()");
        list.stream().dropWhile(x -> x < 3).forEach(System.out::println);

        System.out.println("ofNullable()");
        // JDK8中，Stream不能完全為null；JDK9中，ofNullAble()允許建立單元素為null的Stream
        Stream.of(1, 2, null);
        //        Stream.of(null);// java.lang.NullPointerException
        Stream.ofNullable(null);
        System.out.println(Stream.ofNullable(null).count());// 0

        System.out.println("iterate()重載方法");
        // JDK8，用iterate()産出的Stream需要靠額外的判斷停止
        Stream.iterate(0, x -> x + 1).limit(10).forEach(System.out::println);
        // JDK9，可以直接在iterate()中設定停止的判斷
        Stream.iterate(0, x -> x < 10, x -> x++).forEach(System.out::println);
    }

    @Test
    @DisplayName("Optional新增Stream API")
    public void testcase02() {
        final List<String> list = Arrays.asList("Mickey", "Tai", "Molly");
        final Stream<String> flatMap = Optional.ofNullable(list).stream().flatMap(l -> l.stream());
        flatMap.forEach(System.out::println);
    }
}
