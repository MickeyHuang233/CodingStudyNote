package com.mickey.study;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class T14_TryCatch {
    @Test
    @DisplayName("JDK7之前寫法")
    public void testcase01() {
        final InputStreamReader reader = new InputStreamReader(System.in);
        try {
            reader.read();
        } catch (final IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Test
    @DisplayName("JDK7、JDK8建議寫法，執行完畢會自己調用close()")
    public void testcase02() {
        try (InputStreamReader reader = new InputStreamReader(System.in)) {
            reader.read();
        } catch (final IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    @DisplayName("JDK9可在try()中添加已實例化的final對象")
    public void testcase03() {
        final InputStreamReader reader = new InputStreamReader(System.in);
        final OutputStreamWriter writer = new OutputStreamWriter(System.out);
        try (reader; writer) {
            reader.read();
        } catch (final IOException e) {
            e.printStackTrace();
        }
    }
}
