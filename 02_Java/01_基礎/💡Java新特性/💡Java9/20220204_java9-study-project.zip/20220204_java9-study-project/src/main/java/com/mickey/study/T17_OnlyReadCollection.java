package com.mickey.study;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class T17_OnlyReadCollection {
    @Test
    @DisplayName("JDK9前，建立只讀集合")
    public void testcase01() {
        final List<String> list = new ArrayList<>();
        list.add("Mickey");
        list.add("Tai");
        list.add("Molly");
        // 建立只讀List
        final Collection<String> onlyReadList = Collections.unmodifiableCollection(list);
        onlyReadList.forEach(System.out::println);
        //        onlyReadList.add("Jack");// 執行會報錯，java.lang.UnsupportedOperationException
        // 建立只讀Set
        final Set<String> onlyReadSet = Collections.unmodifiableSet(new HashSet<String>(list));
        // 建立只讀Map
        final Map<String, Integer> onlyReadMap = Collections.unmodifiableMap(new HashMap<String, Integer>() {
            {
                for (final String str : list) {
                    this.put(str, (int) (100 * Math.random()));
                }
            }
        });
        onlyReadMap.forEach((k, v) -> System.out.println(k + " - " + v));
    }

    @Test
    @DisplayName("JDK9，建立只讀集合")
    public void testcase02() {
        // 建立只讀List
        final List<String> onlyReadList = List.of("Mickey", "Tai", "Molly");
        onlyReadList.forEach(System.out::println);
        //        onlyReadList.add("Jack");// 執行會報錯，java.lang.UnsupportedOperationException
        // 建立只讀Set
        final Set<String> onlyReadSet = Set.of("Mickey", "Tai", "Molly");
        // 建立只讀Map
        final Map<String, Integer> onlyReadMap1 = Map.of("Mickey", 233, "Tai", 123, "Molly", 456);
        final Map<String, Integer> onlyReadMap2 = //
                Map.ofEntries(Map.entry("Mickey", 233), Map.entry("Tai", 123), Map.entry("Molly", 456));
    }
}
