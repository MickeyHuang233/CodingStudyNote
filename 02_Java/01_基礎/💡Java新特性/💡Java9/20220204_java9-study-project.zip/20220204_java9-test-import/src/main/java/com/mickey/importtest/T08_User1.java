package com.mickey.importtest;

public class T08_User1 {
    private String name;
    private int age;

    public T08_User1(final String name, final int age) {
        super();
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return this.name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public int getAge() {
        return this.age;
    }

    public void setAge(final int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "T08_User1 [name=" + this.name + ", age=" + this.age + "]";
    }
}