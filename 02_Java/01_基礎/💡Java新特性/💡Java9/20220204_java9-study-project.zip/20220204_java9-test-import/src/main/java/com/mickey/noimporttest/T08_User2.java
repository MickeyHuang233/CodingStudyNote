package com.mickey.noimporttest;

public class T08_User2 {
    private String name;
    private int age;

    public T08_User2(final String name, final int age) {
        super();
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return this.name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public int getAge() {
        return this.age;
    }

    public void setAge(final int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "T08_User2 [name=" + this.name + ", age=" + this.age + "]";
    }
}