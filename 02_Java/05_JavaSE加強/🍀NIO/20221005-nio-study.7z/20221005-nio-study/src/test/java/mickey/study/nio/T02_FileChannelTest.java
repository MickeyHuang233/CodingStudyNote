package mickey.study.nio;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class T02_FileChannelTest {
	@Test
	@DisplayName("FileChannel讀操作")
	public void test01() throws IOException {
		// 建立FileChannel
		RandomAccessFile randomAccessFile = new RandomAccessFile( //
				"D:\\note.txt", // 文件路徑
				"rw"); // Channel模式：r，只讀；rw，讀寫；rws，SYNC；rwd，DSYNC
		FileChannel channel = randomAccessFile.getChannel();
		// 建立Buffer
		ByteBuffer buffer = ByteBuffer.allocate(1024);
		// 讀取數據至緩沖區
		int bytesRead = channel.read(buffer); // 讀取字節數
		while (bytesRead != -1) { // bytesRead為-1表示到文件未尾
			// 初始化position
			buffer.flip();
			System.out.println(new String(buffer.array()));
			// 清空緩存
			buffer.clear();
			// 讀取下一行
			bytesRead = channel.read(buffer);
		}
		// 關閉channel
		channel.close();
		randomAccessFile.close();
	}

	@Test
	@DisplayName("FileChannel寫操作")
	public void test02() throws IOException {
		// 建立FileChannel
		RandomAccessFile randomAccessFile = new RandomAccessFile("D:\\note_01.txt", "rw");
		FileChannel channel = randomAccessFile.getChannel();
		// 建立Buffer
		ByteBuffer buffer = ByteBuffer.allocate(1024);
		buffer.clear();
		// 寫入數據至緩沖區
		buffer.put("mickey study nio fileChannel".getBytes());
		// 初始化position
		buffer.flip();
		// 寫入文件
		channel.write(buffer);
		// 關閉channel
		channel.close();
		randomAccessFile.close();
	}

	@Test
	@DisplayName("FileChannel其他方法")
	public void test03() throws IOException {
		RandomAccessFile randomAccessFile = new RandomAccessFile("D:\\note_01.txt", "rw");
		FileChannel channel = randomAccessFile.getChannel();
		ByteBuffer buffer = ByteBuffer.allocate(1024);

		// 取得當前FileChannel位置
		System.out.println("channel.position() : " + channel.position());
		// 設置FileChannel位置
		// 注意：若將位置設置於文件結束符後，可能道致磁盤上物理文件中的數據有空隙，也就是"文件空洞"
		channel.position(10);
		buffer.put("(put new message)".getBytes());
		buffer.flip();
		channel.write(buffer);

		// 取得文件的總大小
		System.out.println("channel.size() : " + channel.size());

		// 截取文件長度，指定長度後的文字會刪除
		channel.truncate(20);

		// 將Channel中尚未寫入磁盤的數據強制寫入，出於性能，操作系統會將數據緩存至內存中
		channel.force(true); // true，表示同時將文件元數據(取限信息…)寫入磁盤

		channel.close();
		randomAccessFile.close();
	}

	@Test
	@DisplayName("Channel間數據傳輸_transferFrom")
	public void test04() throws IOException {
		RandomAccessFile fromRandomAccessFile = new RandomAccessFile("D:\\note.txt", "rw");
		RandomAccessFile toRandomAccessFile = new RandomAccessFile("D:\\note_02.txt", "rw");
		FileChannel fromChannel = fromRandomAccessFile.getChannel();
		FileChannel toChannel = toRandomAccessFile.getChannel();

		toChannel.transferFrom(fromChannel, 0, fromChannel.size());

		fromChannel.close();
		toChannel.close();
	}

	@Test
	@DisplayName("Channel間數據傳輸_transferTo")
	public void test05() throws IOException {
		RandomAccessFile fromRandomAccessFile = new RandomAccessFile("D:\\note.txt", "rw");
		RandomAccessFile toRandomAccessFile = new RandomAccessFile("D:\\note_03.txt", "rw");
		FileChannel fromChannel = fromRandomAccessFile.getChannel();
		FileChannel toChannel = toRandomAccessFile.getChannel();

		fromChannel.transferTo(0, fromChannel.size(), toChannel);

		fromChannel.close();
		toChannel.close();
	}
}
