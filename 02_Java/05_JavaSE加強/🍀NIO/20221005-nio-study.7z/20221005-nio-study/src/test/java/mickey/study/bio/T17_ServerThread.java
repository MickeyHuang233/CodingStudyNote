package mickey.study.bio;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;

/**
 * 傳統服務端_接收多個客戶端，端口轉發
 * 
 * @author 2106002
 *
 */
public class T17_ServerThread extends Thread {
    private Socket socket;

    public T17_ServerThread(Socket socket) {
        super();
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            // Socket取得輸入流，並包裝成緩沖輸入流
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            // 取得消息內容
            String message;
            while ((message = bufferedReader.readLine()) != null) {
                // 將消息推送至所有客戶端
                this.sendMessageToAllSocket(message);
            }
        } catch (IOException e) {
            // 當前有socket下線
            T04_SocketTest.socketList.remove(socket);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 將消息推送至所有客戶端
     * 
     * @param message 消息內容
     * @throws IOException 
     */
    private void sendMessageToAllSocket(String message) throws IOException {
        for (Socket socket : T04_SocketTest.socketList) {
            PrintStream printStream = new PrintStream(socket.getOutputStream());
            printStream.println(message);
            printStream.flush();
        }
    }
}
