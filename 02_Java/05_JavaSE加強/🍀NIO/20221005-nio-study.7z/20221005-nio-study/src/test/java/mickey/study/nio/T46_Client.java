package mickey.study.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

/*
 * 群聊客戶端
 */
public class T46_Client {
	private Selector selector;
	private SocketChannel socketChannel;
	private static int PORT = 8888;

	public T46_Client() {
		try {
			this.selector = Selector.open();
			this.socketChannel = SocketChannel.open(new InetSocketAddress("127.0.0.1", PORT));
			this.socketChannel.configureBlocking(false);
			this.socketChannel.register(selector, SelectionKey.OP_READ);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*
	 * 監聽服務端發送的消息
	 */
	public void readMessageFromServer() {
		try {
			while (this.selector.select() > 0) {
				Iterator<SelectionKey> iterator = this.selector.selectedKeys().iterator();
				while (iterator.hasNext()) {
					SelectionKey selectionKey = iterator.next();
					// 讀取消息
					if (selectionKey.isReadable()) { // 排除其他事件
						SocketChannel socketChannel = (SocketChannel) selectionKey.channel();
						ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
						socketChannel.read(byteBuffer);
						System.out.println("\n" + new String(byteBuffer.array()).trim());
						System.out.print("Send Message : ");
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*
	 * 發送消息至服務端
	 * 
	 * @param message
	 */
	public void sendMessage(String message) {
		try {
			ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
			byteBuffer.put(message.getBytes());
			byteBuffer.flip();
			this.socketChannel.write(byteBuffer);
			byteBuffer.clear();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
