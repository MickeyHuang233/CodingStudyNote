package mickey.study.bio;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

public class T04_SocketTest {
    @Test
    @DisplayName("Server測試_多收")
    public void test01() {
        // 如果要接收多個Client消息，需要使用多線程
        System.out.println("Start Server");
        try {
            // 定義ServerSocket注冊端口
            ServerSocket serverSocket = new ServerSocket(8888);
            // 監聽Socket請求
            Socket socket = serverSocket.accept();
            // 從Socket取得字節輸入流
            InputStream inputStream = socket.getInputStream();
            // 將字節輸入流包裝為緩沖字節輸入流
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            // 處理接收的信息
            String message;
            while ((message = bufferedReader.readLine()) != null) {
                System.out.println("Server get message : " + message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    @DisplayName("Client測試_多發")
    public void test02() {
        System.out.println("Start Client");
        try {
            // 建立Socket，請求服務連接
            Socket socket = new Socket("127.0.0.1", 8888);
            // 取得Socket取得字節輸出流
            OutputStream outputStream = socket.getOutputStream();
            // 將字節輸出流包裝為打印流
            PrintStream printStream = new PrintStream(outputStream);
            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.print("send message : ");
                String nextLine = scanner.nextLine();
                //				printStream.print(nextLine); // print()，此行信息並未結束
                printStream.println(nextLine); // println()，此行信息換行結束
                printStream.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    @DisplayName("Server測試_接收多客戶端")
    public void test03() {
        System.out.println("Start Server");
        try {
            // 定義ServerSocket注冊端口
            ServerSocket serverSocket = new ServerSocket(8888);
            // 持繼監聽Socket請求，新建線程處理
            while (true) {
                Socket socket = serverSocket.accept();
                new T07_ServerThread(socket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    @DisplayName("Server測試_偽異步")
    public void test04() {
        System.out.println("Start Server");
        try {
            // 定義ServerSocket注冊端口
            ServerSocket serverSocket = new ServerSocket(8888);
            // 初始化線程池
            T11_ServerThreadPool serverThreadPool = new T11_ServerThreadPool(5, 10);
            // 持繼監聽Socket請求，交由線程池處理
            while (true) {
                Socket socket = serverSocket.accept();
                T11_ServerThread serverThread = new T11_ServerThread(socket);
                serverThreadPool.doExecute(serverThread);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    @DisplayName("Client測試_文件上傳")
    public void test05() {
        System.out.println("Start Client");
        File uploadFile = new File("D:\\2021091915263900_s.jpg");
        try ( //
                InputStream fileInputStream = new FileInputStream(uploadFile); //
        ) {
            // 建立Socket，請求服務連接
            Socket socket = new Socket("127.0.0.1", 8888);
            // 將字節輸出流包裝為數據輸出流
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
            // 發送文件類型給服務端
            String filelName = uploadFile.getName();
            int fileTypeIndex = filelName.lastIndexOf(".");
            String fileType = "";
            if (fileTypeIndex != -1) {
                fileType = filelName.substring(fileTypeIndex);
            }
            dataOutputStream.writeUTF(fileType);
            // 發送文件數據
            byte[] buffer = new byte[1024];
            int len;
            while ((len = fileInputStream.read(buffer)) > 0) {
                dataOutputStream.write(buffer, 0, len);
            }
            dataOutputStream.flush();
            // 通知服務端發送完畢
            socket.shutdownOutput();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    @DisplayName("Server測試_文件接收")
    public void test06() {
        System.out.println("Start Server");
        try {
            // 定義ServerSocket注冊端口
            ServerSocket serverSocket = new ServerSocket(8888);
            // 持繼監聽Socket請求，新建線程處理
            while (true) {
                Socket socket = serverSocket.accept();
                new T14_ServerThread(socket).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 所有已連線Socket列表
    public static List<Socket> socketList = new ArrayList<Socket>();

    @Test
    @DisplayName("Server測試_瑞口轉發")
    public void test07() {
        System.out.println("Start Server");
        try {
            ServerSocket serverSocket = new ServerSocket(8888);
            // 持繼監聽Socket請求，新建線程處理
            while (true) {
                Socket socket = serverSocket.accept();
                new T17_ServerThread(socket).start();
                // 將已連線Socket加入集合
                socketList.add(socket);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    @DisplayName("Client測試_邊發邊收")
    public void test08() {
        System.out.println("Start Client");
        try {
            // 建立Socket，請求服務連接
            Socket socket = new Socket("127.0.0.1", 8888);
            // 取得Socket取得字節輸出流
            OutputStream outputStream = socket.getOutputStream();
            // 新建線程，監聽消息
            new T19_ClientThread(socket).start();
            // 將字節輸出流包裝為打印流
            PrintStream printStream = new PrintStream(outputStream);
            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.print("send message : ");
                String nextLine = scanner.nextLine();
                printStream.println(nextLine);
                printStream.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
