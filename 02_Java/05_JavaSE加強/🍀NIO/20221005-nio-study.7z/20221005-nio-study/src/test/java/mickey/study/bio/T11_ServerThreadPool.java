package mickey.study.bio;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 偽異步IO，線程池
 * 
 * @author 2106002
 *
 */
public class T11_ServerThreadPool {
    // 線程池
    private ExecutorService executorService;

    /**
     * 初始化線程池對象
     * 
     * @param maxThreadSize 線程池中線程數量
     * @param messageQueueSize 任務隊列數量
     */
    public T11_ServerThreadPool(int maxThreadSize, int messageQueueSize) {
        this.executorService = new ThreadPoolExecutor( //
                4, // corePoolSize，最小線程數
                maxThreadSize, // maximumPoolSize，最大線程數
                2, // keepAliveTime，過期時間
                TimeUnit.MINUTES, // unit，單位
                new ArrayBlockingQueue<>(messageQueueSize)); // workQueue，任務隊列
    }

    /**
     * 將任務給線程池執行
     * 
     * @param runnable 任務
     */
    public void doExecute(Runnable runnable) {
        this.executorService.execute(runnable);
    }
}
