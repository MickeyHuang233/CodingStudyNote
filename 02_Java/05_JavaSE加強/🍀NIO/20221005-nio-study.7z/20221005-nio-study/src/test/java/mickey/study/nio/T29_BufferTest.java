package mickey.study.nio;

import java.nio.ByteBuffer;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

public class T29_BufferTest {
	@Test
	@DisplayName("NIO_Buffer常用API")
	public void test01() throws Exception {
		// 建立指定容量Buffer
		ByteBuffer byteBuffer = ByteBuffer.allocate(10);
		this.printBufferVar(byteBuffer);
		// 在Buffer添加數據
		byteBuffer.put("Hello".getBytes());
		this.printBufferVar(byteBuffer);
		// 將Buffer limit設置為當前位置，並將position設置為0，轉換為讀模式
		byteBuffer.flip();
		this.printBufferVar(byteBuffer);
		// 讀取數據
		System.out.println((char) byteBuffer.get()); // 讀取1個字節，H
		byte[] b = new byte[2];
		byteBuffer.get(b); // 讀取多個字節，el
		System.out.println(new String(b));
		this.printBufferVar(byteBuffer);
		// 標記position
		byteBuffer.mark();
		System.out.println((char) byteBuffer.get()); // l
		// 返回標記position
		byteBuffer.reset();
		// position後是否還有數據
		if (byteBuffer.hasRemaining()) {
			// 取得未讀取數據數
			System.out.println("byteBuffer.remaining() : " + byteBuffer.remaining());
		}
		// 清除緩沖區數據，但實際上只是將position設置為0，添加數據時才會覆蓋原數據
		byteBuffer.clear();
		System.out.println((char) byteBuffer.get());
		this.printBufferVar(byteBuffer);
	}

	// 查看基本屬性
	private void printBufferVar(ByteBuffer byteBuffer) {
		System.out.println("byteBuffer.capacity() : " + byteBuffer.capacity());
		System.out.println("byteBuffer.limit() : " + byteBuffer.limit());
		System.out.println("byteBuffer.position() : " + byteBuffer.position());
		System.out.println("---------");
	}

	@Test
	@DisplayName("直接緩沖區")
	public void test02() {
		// 建立直接緩沖區
		ByteBuffer byteBuffer = ByteBuffer.allocateDirect(10);
		// 緩沖區是否為直接緩沖區
		System.out.println(byteBuffer.isDirect());
	}

	@Test
	@DisplayName("非直接緩沖區")
	public void test03() {
		// 建立非直接緩沖區
		ByteBuffer byteBuffer = ByteBuffer.allocate(10);
		// 緩沖區是否為直接緩沖區
		System.out.println(byteBuffer.isDirect());
	}
}
