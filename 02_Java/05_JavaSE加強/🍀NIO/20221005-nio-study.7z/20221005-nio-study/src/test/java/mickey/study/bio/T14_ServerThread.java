package mickey.study.bio;

import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.UUID;

/**
 * 傳統服務端_接收多個客戶端，文件上傳
 * @author 2106002
 *
 */
public class T14_ServerThread extends Thread {
    private Socket socket;

    public T14_ServerThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            // 從Socket取得字節輸入流
            DataInputStream dataInputStream = new DataInputStream(this.socket.getInputStream());
            // 取得文件接收類型
            String fileType = dataInputStream.readUTF();
            System.out.println("get file type : " + fileType);
            // 將接收的文件輸出至本機
            OutputStream fileOutputStream = new FileOutputStream("D:\\server\\" + UUID.randomUUID().toString() + fileType);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = dataInputStream.read(buffer)) > 0) {
                fileOutputStream.write(buffer, 0, len);
            }
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
