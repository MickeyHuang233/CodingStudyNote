package mickey.study.bio;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

/*
 * 偽異步IO，線程任務
 */
public class T11_ServerThread implements Runnable {
	private Socket socket;

	public T11_ServerThread(Socket socket) {
		super();
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			// 從Socket取得字節輸入流
			InputStream inputStream = socket.getInputStream();
			// 將字節輸入流包裝為緩沖字節輸入流
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			// 處理接收的信息
			String message;
			while ((message = bufferedReader.readLine()) != null) {
				long threadId = Thread.currentThread().getId();
				System.out.println("Server get message : " + threadId + " - " + message);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
