package mickey.study.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Channel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

/*
 * 群聊服務端
 */
public class T44_Server {
	private Selector selector;
	private ServerSocketChannel serverSocketChannel;
	private static final int PORT = 8888;

	public T44_Server() {
		try {
			// 建立選擇器
			this.selector = Selector.open();
			// 建立通道
			this.serverSocketChannel = ServerSocketChannel.open();
			// 切換非阻塞模式
			this.serverSocketChannel.configureBlocking(false);
			// 指定連線端口
			this.serverSocketChannel.bind(new InetSocketAddress(PORT));
			// 將通道注冊至選擇器上，並指定監聽事件
			this.serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * 開始監聽服務
	 */
	public void listen() {
		try {
			// 處理就緒好的事件
			while (this.selector.select() > 0) {
				// 遍歷已就緒的事件
				Iterator<SelectionKey> iterator = this.selector.selectedKeys().iterator();
				while (iterator.hasNext()) {
					SelectionKey selectionKey = iterator.next();
					// 客戶端初次連線
					if (selectionKey.isAcceptable()) {
						// 取得客戶端Socket通道，並切換為非阻塞模式、注冊至選擇器
						SocketChannel socketChannel = this.serverSocketChannel.accept();
						socketChannel.configureBlocking(false);
						socketChannel.register(selector, SelectionKey.OP_READ);
					}
					// 客戶端發送消息
					else if (selectionKey.isReadable()) {
						// 處理客戶端發送的信息，轉發至所有已連線客戶端
						this.processClientMessage(selectionKey);
					}
					// 移除已處理事件
					iterator.remove();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*
	 * 處理客戶端發送的信息，轉發至所有已連線客戶端
	 */
	private void processClientMessage(SelectionKey selectionKey) {
		SocketChannel socketChannel = null;
		try {
			socketChannel = (SocketChannel) selectionKey.channel();
			// 取得客戶端通道信息
			ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
			int readCount = socketChannel.read(byteBuffer);
			if (readCount > 0) { // 有讀取到才處理
				// 初始化緩沖區position
				byteBuffer.flip();
				String message = new String(byteBuffer.array(), 0, byteBuffer.remaining());
				this.sendMessageToAllClient(message, socketChannel);
			}
		} catch (Exception e) {
			// 表示當前客戶端離線，關閉、取消通道連線
			selectionKey.cancel();
			try {
				socketChannel.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * 發送消息至所有已連線客戶端
	 * 
	 * @param message 消息內容
	 */
	private void sendMessageToAllClient(String message, SocketChannel curretChannel) {
		System.out.println("send client message : " + Thread.currentThread().getName() + " : " + message);
		try {
			// 取得所有客戶端通道
			for (SelectionKey selectionKey : this.selector.keys()) {
				Channel channel = selectionKey.channel();
				// 排除通道
				if ( //
				channel instanceof SocketChannel && channel == curretChannel // 當前通道
						|| selectionKey.isAcceptable() // 初次連線用的通道
				) {
					continue;
				}
				ByteBuffer byteBuffer = ByteBuffer.wrap(message.getBytes());
				((SocketChannel) channel).write(byteBuffer);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
