package mickey.study.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Scanner;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

public class T40_SelectorTest {
	@Test
	@DisplayName("Selector_服務端")
	public void test01() throws IOException {
        System.out.println("Start Server");
		// 當Client連線至Server時，Server會通過ServerSocketChannel得到SocketChannel
		ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
		// 切換非阻塞模式
		serverSocketChannel.configureBlocking(false);
		// 指定連線端口
		serverSocketChannel.bind(new InetSocketAddress(8888));
		// 取得選擇器
		Selector selector = Selector.open();
		// 將通道注冊至選擇器上，並指定監聽事件
		serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
		// 處理選擇器中已經就緒好的事件
		while (selector.select() > 0) {
			// 取得所有已注冊通道中已經就緒的事件
			Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
			// 遍歷已就緒的事件
			while (iterator.hasNext()) {
				// 取得要處理事件
				SelectionKey selectionKey = iterator.next();
				// 事件為接收事件，相當於就是讀事件
				if (selectionKey.isAcceptable()) {
					// 取得接入的客戶端Socket通道
					SocketChannel socketChannel = serverSocketChannel.accept();
					// 切換非阻塞模式
					socketChannel.configureBlocking(false);
					// 將客戶端Socket通道注冊至選擇器
					socketChannel.register(selector, SelectionKey.OP_READ);
				}
				// 事件為讀取事件
				else if (selectionKey.isReadable()) {
					// 取得要處理Socket通道
					SocketChannel socketChannel = (SocketChannel) selectionKey.channel();
					// 讀取數據
					ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
					int len = 0;
					while ((len = socketChannel.read(byteBuffer)) > 0) {
						byteBuffer.flip();
						System.out.println(new String(byteBuffer.array(), 0, byteBuffer.remaining()));
						byteBuffer.clear();
					}
				}
				// 處理完畢，將教緒好事件移除
				iterator.remove();
			}
		}
	}

	@Test
	@DisplayName("Selector_客戶端")
	public void test02() throws IOException {
        System.out.println("Start Client");
		// 取得通道
		SocketChannel socketChannel = SocketChannel.open(new InetSocketAddress("127.0.0.1", 8888));
		// 切換非阻塞模式
		socketChannel.configureBlocking(false);
		// 建立緩沖區
		ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
		// 發送數據至Server
		Scanner scanner = new Scanner(System.in);
		while(true) {
			System.out.print("Send Message : ");
			String message = scanner.nextLine();
			byteBuffer.put(message.getBytes());
			byteBuffer.flip();
			socketChannel.write(byteBuffer);
			byteBuffer.clear();
		}
	}
	
	@Test
	@DisplayName("群聊功能_服務端")
	public void test03() {
		System.out.println("Start Server");
		T44_Server server = new T44_Server();
		server.listen();
	}
	
	@Test
	@DisplayName("群聊功能_客戶端_多接多發")
	public void test04() {
		System.out.println("Start Client");
		T46_Client client = new T46_Client();
		// 定義新線程監聽Server發送的消息
		new Thread(new Runnable() {
			@Override
			public void run() {
				client.readMessageFromServer();
			}
		}).start();
		// 發送數據至Server
		Scanner scanner = new Scanner(System.in);
		while(true) {
			System.out.print("Send Message : ");
			String message = scanner.nextLine();
			client.sendMessage(message);
		}
	}
}
