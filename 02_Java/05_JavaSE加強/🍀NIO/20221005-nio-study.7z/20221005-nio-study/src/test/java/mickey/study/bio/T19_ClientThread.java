package mickey.study.bio;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class T19_ClientThread extends Thread{
    private Socket socket;

    public T19_ClientThread(Socket socket) {
        super();
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            while (true) {
                // 將字節輸入流包裝為緩沖字節輸入流
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
                // 處理接收的信息
                String message;
                while ((message = bufferedReader.readLine()) != null) {
                    System.out.println("\nGet message : " + message);
                    System.out.print("send message : ");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
