package mickey.study.bio;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 * 傳統服務端_接收多個客戶端
 * 
 * @author 2106002
 *
 */
public class T07_ServerThread extends Thread {
    private Socket socket;

    public T07_ServerThread(Socket socket) {
        super();
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            // 從Socket取得字節輸入流
            InputStream inputStream = socket.getInputStream();
            // 將字節輸入流包裝為緩沖字節輸入流
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            // 處理接收的信息
            String message;
            while ((message = bufferedReader.readLine()) != null) {
                System.out.println("Server get message : " + this.getName() + " - " + message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
