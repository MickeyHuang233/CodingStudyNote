package mickey.study.nio;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

public class T33_ChannelTest {
	@Test
	@DisplayName("FileChannel寫操作")
	public void test01() {
		try (
				// 建立通道
				FileOutputStream fileOutputStream = new FileOutputStream("D:\\test_01.txt");
//				FileOutputStream fileOutputStream = new FileOutputStream("‪D:\\test_new.txt");
				FileChannel channel = fileOutputStream.getChannel(); //
		) {
			// 建立緩沖流
			ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
			byteBuffer.put("Hello World".getBytes());
			// 初始化position
			byteBuffer.flip();
			// 寫入數據
			channel.write(byteBuffer);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	@DisplayName("FileChannel讀操作")
	public void test02() {
		try (
				// 建立通道
				FileInputStream fileInputStream = new FileInputStream("D:\\test.txt");
				FileChannel channel = fileInputStream.getChannel(); //
		) {
			// 建立緩沖流
			ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
			// 讀取數據
			channel.read(byteBuffer);
			// 初始化position
			byteBuffer.flip();
			String str = new String(byteBuffer.array(), 0, byteBuffer.remaining());
			System.out.println(str);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	@DisplayName("FileChannel文件複製")
	public void test03() throws IOException {
		try (
				// 建立通道
				FileInputStream fileInputStream = new FileInputStream("D:\\test.jpg");
				FileChannel inputChannel = fileInputStream.getChannel();
				// 建立輸出流通道
				FileOutputStream fileOutputStream = new FileOutputStream("D:\\test_01.jpg");
				FileChannel outputChannel = fileOutputStream.getChannel(); //
		) {
			// 建立緩沖區
			ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
			// 執行數據傳送
			while (true) {
				byteBuffer.clear(); // 先清空數據再寫入緩沖區
				int bytesRead = inputChannel.read(byteBuffer);
				// 無讀取到數據
				if (bytesRead == -1) {
					break;
				}
				// 初始化position
				byteBuffer.flip();
				// 緩沖區輸出
				outputChannel.write(byteBuffer);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	@DisplayName("FileChannel分散")
	public void test04() {
		try (
				// 建立通道
				FileInputStream fileInputStream = new FileInputStream("D:\\test.txt");
				FileChannel channel = fileInputStream.getChannel(); //
		) {
			// 建立多個綏沖區
			ByteBuffer[] byteBuffers = { //
					ByteBuffer.allocate(4), //
					ByteBuffer.allocate(1024), //
			};
			// 從通道讀取數據至各緩沖區中
			channel.read(byteBuffers);
			// 打印緩緩區數據
			for (ByteBuffer buffer : byteBuffers) {
				buffer.flip();
				System.out.println(new String(buffer.array(), 0, buffer.remaining()));
				System.out.println("-----");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	@DisplayName("FileChannel聚集")
	public void test05() {
		try (
				// 建立通道
				FileOutputStream fileOutputStream = new FileOutputStream("D:\\test01.txt");
				FileChannel channel = fileOutputStream.getChannel(); //
		) {
			// 建立多個緩沖區
			ByteBuffer[] byteBuffers = { //
					ByteBuffer.allocate(10), //
					ByteBuffer.allocate(20), //
			};
			// 緩沖區添加數據
			byteBuffers[0].put("Hello, ".getBytes());
			byteBuffers[1].put("FileChannel Gather!".getBytes());
			// 重置position
			for (ByteBuffer buffer : byteBuffers) {
				buffer.flip();
			}
			// 緩沖區輸出
			channel.write(byteBuffers);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
