package mickey.study.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class T08_ServerSocketChannelTest {
    @Test
    @DisplayName("ServerSocketChannel")
    public void test01() throws IOException, InterruptedException {
        // ?��?��端口???
        int port = 8888;
        ByteBuffer byteBuffer = ByteBuffer.wrap("Hello World!".getBytes());
        // ServerSocketChannel綁�?�端?��
        ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
        serverSocketChannel.bind(new InetSocketAddress(port));
        // 設置??�阻塞模�?
        serverSocketChannel.configureBlocking(false);
        // ?��?��????�新??�接
        // http://127.0.0.1:8888/
        while (true) {
            SocketChannel socketChannel = serverSocketChannel.accept();
            if (socketChannel == null) {
                System.out.println("no connection");
                Thread.sleep(2000);
            } else {
                System.out.println("connection : "+ socketChannel.socket().getRemoteSocketAddress());
                byteBuffer.rewind(); // 將�?��?��?��?��?��??
                socketChannel.write(byteBuffer);
                socketChannel.close();
            }
        }
    }
}
